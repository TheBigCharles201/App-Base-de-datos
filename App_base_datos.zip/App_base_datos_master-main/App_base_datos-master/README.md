# App_base_datos

![Alt Text](BaseDatosSQLite.png)
